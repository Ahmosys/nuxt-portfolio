<template>
  <Button variant="ghost" size="icon">
    <Icon name="lucide:command" class="h-[1.2rem] w-[1.2rem]" />
  </Button>
</template>

<script lang="ts" setup></script>

<style></style>
