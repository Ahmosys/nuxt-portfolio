<template>
  <div
    class="flex flex-col w-full max-w-screen-xl mx-auto mt-16 mb-16 sm:mt-32"
  >
    <h2
      class="text-3xl font-semibold leading-none tracking-tight md:text-3xl lg:text-3xl"
    >
      01. Work with
    </h2>
    <p class="mb-10 text-muted-foreground">
      Some of the technologies I work with.
    </p>
    <div class="flex items-center">
      <TechstackCard />
      <TechstackOrbit />
    </div>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped></style>
