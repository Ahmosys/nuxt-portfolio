<template>
  <div
    class="inline-flex items-center rounded-lg border px-3 py-1 text-sm font-medium mb-4"
  >
    <span class="relative flex h-2 w-2 mr-2"
      ><span
        class="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-700 opacity-75"
      ></span
      ><span
        class="relative inline-flex h-2 w-2 rounded-full bg-green-700"
      ></span></span
    ><span class="sm:inline">Currently Online</span>
  </div>
</template>

<script lang="ts" setup></script>

<style></style>
