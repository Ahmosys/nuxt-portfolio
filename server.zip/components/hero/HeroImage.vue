<template>
  <img
    src="/hero-pfp.jpg"
    alt="Profile Picture"
    class="rounded-full h-[13rem] w-[13rem] object-cover my-5 border-2 transition-transform ease-in-out duration-500 hover:scale-110"
  />
</template>

<script lang="ts" setup></script>

<style></style>
