<template>
  <Hero />
  <Techstack />
  <Course />
</template>

<script setup lang="ts"></script>
